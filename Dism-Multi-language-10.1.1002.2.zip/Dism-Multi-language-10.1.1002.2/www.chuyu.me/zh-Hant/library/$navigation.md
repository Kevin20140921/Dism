﻿
#### [關於 Dism++](?file=start.md "返回")

##### 1. 快速入門
- [1.1 快速入門](?file=Quickstart.md "快速入門")
- [1.2 Dism 轉 Dism++ 入門](?file=Dism2Dism++.md "Dism轉Dism++入門")

##### 2. 進階使用
- [2.1. Dism++ 術語](?file=Dism++Library/術語.md "Dism++術語")
- [2.2. Dism++ 隱藏設定](?file=Dism++Library/隱藏功能.md "Dism++隱藏設定")
- [2.3. 自訂規則](?file=Dism++Library/自訂規則.md "自訂規則")
- [2.4. 規則結構參考](?file=Dism++Library/規則結構參考.md "規則結構參考")
- [2.5. 通用安裝腳本——sut](?file=Dism++Library/Dism++sut.md "通用安裝腳本")

##### 3. Dism++ 最佳實踐
- [3.1. 使用 Dism++ 安裝系統](?file=Best/使用Dism++安裝系統.md "使用Dism++安裝系統")
- [3.2. 給 ISO 離線整合更新](?file=Best/給ISO離線整合更新.md "給ISO離線整合更新")

